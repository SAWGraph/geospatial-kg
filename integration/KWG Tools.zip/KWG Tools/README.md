# Integration across geometric features

This folder contains a script `integrate.py` that can be used to compute and write spatial relations across two sets of geometric features. 

The script makes the following assumptions:
1. Each geometric feature is associated with exactly ONE instance of a geometry with exactly ONE serialization as a WKT literal.   
2. The two sets of geometric features are separated into two distinct paths. 
3. Each such path is either a file containing RDF data or a directory tree containing ONLY RDF data. 
4. All of the geometric features in a path have the same dimension. 

For example, suppose we have the following directory structure 
 ```
├── integrate.py
├── features1
│   ├── features1a.nt
│   ├── features1b.ttl
│   ├── features1c.nt
|   ...
├── features2.ttl
```
Here `features1` is a directory tree containing only RDF data (in `nt` and `ttl` format), and `features2.ttl` is a file containing RDF data in turtle format. Then we could execute the script `integrate.py` by running the command 
```
python3 integrate.py features1 dim1 features2.ttl dim2 output_folder
```
where `dim1` is the dimension of those features in `features1` and `dim2` is the dimension of those features in `features2.ttl` and `output_folder` is the name of the folder you wish to write the output (which the script will create). 
The execution of this script would compute spatial relations between the sets of features from `features1` and `features2.ttl`, and it would write the computed relations to disk in a new folder called `output_folder`. 

More generally, the script can be run by following the command 
```
python3 path_to_script path_to_features_1 dim1 path_to_features_2 dim2 output_folder
```

The script computes the following spatial predicates according to the [Dimensionally Extended 9-Intersection Model](https://en.wikipedia.org/wiki/DE-9IM) (DE9IM):  
 * equals
 * touches
 * contains
 * within
 * crosses 
 * overlaps

 These predicates correspond to similarly named object properties in the KnowWhereGraph ontology. For example, the predicate `equals` corresponds to the object property with IRI `kwg-ont:sfEquals`.  

 ## Note on execution

The script stores all of the features in path2 in memory, as it walks through those features of path1. As a result, performance might be improved if path2 contains LESS geographic information than path1. 

